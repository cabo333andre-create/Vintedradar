VINTED RADAR 2.0 - progetto Android Studio

Versione con ricerche multiple salvate:
- Ogni ricerca può avere nome, categoria, parole chiave, condizione e fascia di prezzo.
- Le ricerche vengono salvate sul dispositivo e restano dopo la chiusura dell'app.
- Pulsante per aprire la ricerca direttamente su Vinted.
- Controllo interno ogni 30 secondi mentre l'app è aperta; nessuna notifica di sistema.
- Possibilità di eliminare le ricerche.

LIMITAZIONE IMPORTANTE:
Questa versione non estrae autonomamente gli annunci né può rilevare con certezza gli ID dei nuovi articoli.
Il controllo automatico aggiorna lo stato delle ricerche salvate; per vedere gli annunci bisogna aprire la pagina Vinted.
Vinted può modificare URL/filtri o richiedere login. Il filtro condizione viene incluso nel testo di ricerca, non è un filtro API garantito.
Per un rilevamento affidabile dei nuovi annunci serve un'integrazione supportata e consentita dalla piattaforma.

CREARE APK:
1. Installa Android Studio su PC.
2. Apri la cartella VintedRadarAndroid_v2.
3. Attendi Gradle Sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug in app/build/outputs/apk/debug/app-debug.apk.
