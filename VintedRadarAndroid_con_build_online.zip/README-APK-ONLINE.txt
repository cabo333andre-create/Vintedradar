VINTED RADAR 2.0 — compilazione APK online senza PC

Questo archivio include il progetto Android e una GitHub Actions workflow per creare l'APK in cloud.
Non contiene un APK già compilato. La compilazione richiede di caricare il progetto su GitHub e avviare il workflow.

PASSAGGI DA TELEFONO:
1. Scarica e decomprimi questo ZIP usando il gestore file Android.
2. Apri https://github.com/ e accedi/crea un account.
3. Crea un nuovo repository (consigliato privato) chiamato VintedRadar.
4. Dal browser GitHub usa "Add file" > "Upload files" e carica tutti i file e cartelle del progetto decompresso, inclusa la cartella nascosta .github/workflows/android-apk.yml. Se il sito mobile non mostra le cartelle nascoste, abilita la visualizzazione file nascosti o carica prima tramite un'app archivio/file manager che mostri .github.
5. Fai commit dei file nel branch main.
6. Apri la scheda Actions del repository. Se richiesto, abilita GitHub Actions.
7. Seleziona "Build Vinted Radar APK", premi "Run workflow" e conferma.
8. Attendi che il workflow diventi verde. Apri l'esecuzione completata e scarica l'artifact "Vinted-Radar-APK".
9. Estrai l'artifact ZIP: contiene app-debug.apk. Tocca l'APK per installarlo e, se Android lo richiede, consenti l'installazione da questa fonte.

NOTE:
- GitHub può cambiare l'interfaccia mobile; può essere più facile attivare "Sito desktop" nel browser.
- Non inserire segreti o credenziali Vinted nel repository.
- APK debug non è firmato per la distribuzione Play Store; è adatto a test/installazione manuale.
- L'app attuale salva più ricerche e apre le ricerche su Vinted. Il timer ogni 30 secondi aggiorna lo stato interno, ma non estrae in modo affidabile i nuovi annunci da Vinted. I filtri URL possono variare; nessuna garanzia di rilevamento automatico.
