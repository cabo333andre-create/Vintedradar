plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "it.vintedradar.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "it.vintedradar.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
