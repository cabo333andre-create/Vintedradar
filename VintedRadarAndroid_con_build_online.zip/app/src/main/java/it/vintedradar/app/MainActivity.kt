package it.vintedradar.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.Intent
import android.net.Uri
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

data class SavedSearch(
    val id: Long,
    val name: String,
    val category: String,
    val keywords: String,
    val minPrice: String,
    val maxPrice: String,
    val condition: String,
    var url: String,
    var lastChecked: Long = 0L,
    var seenCount: Int = 0
)

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("radar", MODE_PRIVATE) }
    private val searches = mutableListOf<SavedSearch>()
    private val seenUrls = mutableSetOf<String>()
    private lateinit var list: LinearLayout
    private lateinit var countText: TextView
    private lateinit var status: TextView
    private lateinit var category: Spinner
    private lateinit var condition: Spinner
    private lateinit var nameInput: EditText
    private lateinit var keywords: EditText
    private lateinit var minPrice: EditText
    private lateinit var maxPrice: EditText
    private var lastResultsUrl: String = "https://www.vinted.it/catalog"
    private var autoRefresh = true

    private val refreshTask = object : Runnable {
        override fun run() {
            if (autoRefresh) {
                checkSearches()
                handler.postDelayed(this, 30_000L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSaved()
        buildUi()
        renderSearches()
        handler.postDelayed(refreshTask, 30_000L)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245,247,246))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        content.addView(TextView(this).apply {
            text = "Vinted Radar"
            textSize = 28f
            setTextColor(Color.rgb(23,75,59))
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(label("Le tue ricerche salvate · controllo ogni 30 secondi"))
        content.addView(label("Nome della ricerca"))
        nameInput = edit("es. iPhone 14 sotto 250 €")
        content.addView(nameInput, fullHeight())
        content.addView(label("Categoria"))
        category = spinner(listOf("Smartphone", "PC e laptop", "Tablet", "Console", "Accessori elettronici", "Tutti i dispositivi"))
        content.addView(category, fullHeight())
        content.addView(label("Parole chiave (più termini possibili)"))
        keywords = edit("iPhone 14, 128 GB")
        content.addView(keywords, fullHeight())
        content.addView(label("Condizioni"))
        condition = spinner(listOf("Qualsiasi condizione", "Nuovo con etichetta", "Nuovo senza etichetta", "Ottime condizioni", "Buone condizioni", "Condizioni soddisfacenti"))
        content.addView(condition, fullHeight())
        content.addView(label("Prezzo minimo e massimo (€)"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        minPrice = edit("Min €", true)
        maxPrice = edit("Max €", true)
        row.addView(minPrice, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(5) })
        row.addView(maxPrice, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(5) })
        content.addView(row)
        content.addView(Button(this).apply {
            text = "＋ Salva questa ricerca"
            setOnClickListener { saveSearch() }
        }, fullHeight())
        content.addView(Button(this).apply {
            text = "Controlla tutte le ricerche adesso"
            setOnClickListener { checkSearches() }
        }, fullHeight())
        status = label("I risultati si aprono sul sito Vinted. I controlli automatici tentano di riaprire ogni ricerca.")
        content.addView(status)
        countText = label("Ricerche salvate: 0")
        content.addView(countText)
        content.addView(label("RICERCHE SALVATE"))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        content.addView(label("NOTA: per rispettare il funzionamento del sito, questa versione controlla e apre le pagine di ricerca salvate. Non può garantire l'estrazione automatica di ogni nuovo annuncio: Vinted può richiedere accesso o modificare i propri filtri."))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun saveSearch() {
        val terms = keywords.text.toString().trim()
        if (terms.isEmpty()) {
            Toast.makeText(this, "Inserisci almeno una parola chiave", Toast.LENGTH_SHORT).show()
            return
        }
        val cat = category.selectedItem.toString()
        val cond = condition.selectedItem.toString()
        val searchName = nameInput.text.toString().trim().ifEmpty { "$cat · $terms" }
        val url = makeUrl(cat, terms, minPrice.text.toString().trim(), maxPrice.text.toString().trim(), cond)
        val item = SavedSearch(System.currentTimeMillis(), searchName, cat, terms, minPrice.text.toString().trim(),
            maxPrice.text.toString().trim(), cond, url)
        searches.add(0, item)
        persist()
        renderSearches()
        status.text = "Ricerca salvata. Il controllo automatico avviene ogni 30 secondi mentre l'app è aperta."
        Toast.makeText(this, "Ricerca salvata", Toast.LENGTH_SHORT).show()
    }

    private fun makeUrl(cat: String, terms: String, min: String, max: String, cond: String): String {
        val catTerm = when(cat) {
            "Smartphone" -> "smartphone"
            "PC e laptop" -> "PC laptop computer"
            "Tablet" -> "tablet"
            "Console" -> "console PlayStation Xbox Nintendo"
            "Accessori elettronici" -> "accessori elettronica"
            else -> "smartphone PC tablet console"
        }
        val conditionTerm = when(cond) {
            "Nuovo con etichetta" -> "nuovo con etichetta"
            "Nuovo senza etichetta" -> "nuovo senza etichetta"
            "Ottime condizioni" -> "ottime condizioni"
            "Buone condizioni" -> "buone condizioni"
            "Condizioni soddisfacenti" -> "condizioni soddisfacenti"
            else -> ""
        }
        val q = listOf(catTerm, terms, conditionTerm).filter { it.isNotBlank() }.joinToString(" ")
        val params = mutableListOf("search_text=" + enc(q))
        if (min.isNotEmpty()) params.add("price_from=" + enc(min))
        if (max.isNotEmpty()) params.add("price_to=" + enc(max))
        return "https://www.vinted.it/catalog?" + params.joinToString("&")
    }

    private fun checkSearches() {
        if (searches.isEmpty()) {
            status.text = "Aggiungi almeno una ricerca per iniziare."
            return
        }
        val now = System.currentTimeMillis()
        searches.forEach { it.lastChecked = now }
        persist()
        renderSearches()
        status.text = "Ultimo controllo delle ricerche: " + java.text.SimpleDateFormat("HH:mm:ss", Locale.ITALY).format(java.util.Date(now)) +
            ". Apri una ricerca per vedere gli annunci aggiornati su Vinted."
    }

    private fun renderSearches() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        countText.text = "Ricerche salvate: ${searches.size}"
        if (searches.isEmpty()) {
            list.addView(label("Ancora nessuna ricerca. Compila i filtri qui sopra e salva la prima ricerca."))
            return
        }
        searches.forEach { s ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(Color.WHITE)
            }
            card.addView(TextView(this).apply {
                text = s.name
                textSize = 18f
                setTextColor(Color.rgb(23,75,59))
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            card.addView(label("${s.category} · ${s.keywords}"))
            val price = "${s.minPrice.ifEmpty { "0" }} € – ${s.maxPrice.ifEmpty { "senza limite" }}"
            card.addView(label("Prezzo: $price · ${s.condition}"))
            val checked = if (s.lastChecked == 0L) "Non ancora controllata" else
                "Ultimo controllo: " + java.text.SimpleDateFormat("HH:mm:ss", Locale.ITALY).format(java.util.Date(s.lastChecked))
            card.addView(label(checked))
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(Button(this@MainActivity).apply {
                text = "Apri annunci"
                setOnClickListener {
                    lastResultsUrl = s.url
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.url)))
                }
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
            buttons.addView(Button(this@MainActivity).apply {
                text = "Elimina"
                setOnClickListener {
                    searches.removeAll { it.id == s.id }
                    persist()
                    renderSearches()
                }
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
            card.addView(buttons)
            val spacer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            spacer.addView(card)
            list.addView(spacer)
        }
    }

    private fun persist() {
        val arr = JSONArray()
        searches.forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id); put("name", s.name); put("category", s.category); put("keywords", s.keywords)
                put("minPrice", s.minPrice); put("maxPrice", s.maxPrice); put("condition", s.condition)
                put("url", s.url); put("lastChecked", s.lastChecked); put("seenCount", s.seenCount)
            })
        }
        prefs.edit().putString("searches", arr.toString()).apply()
    }

    private fun loadSaved() {
        try {
            val arr = JSONArray(prefs.getString("searches", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                searches.add(SavedSearch(o.optLong("id"), o.optString("name"), o.optString("category"),
                    o.optString("keywords"), o.optString("minPrice"), o.optString("maxPrice"),
                    o.optString("condition"), o.optString("url"), o.optLong("lastChecked"), o.optInt("seenCount")))
            }
        } catch (_: Exception) {}
    }

    private fun edit(hintText: String, numeric: Boolean = false) = EditText(this).apply {
        hint = hintText
        singleLine = true
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }
    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13.5f
        setTextColor(Color.rgb(48,58,52))
        setPadding(0, dp(8), 0, dp(5))
    }
    private fun fullHeight() = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(3) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    override fun onDestroy() {
        autoRefresh = false
        handler.removeCallbacks(refreshTask)
        super.onDestroy()
    }
}
